package com.bumptech.glide.load;

public enum PreferredColorSpace {
    SRGB,
    DISPLAY_P3
}
