package com.bumptech.glide.module;

@Deprecated
public interface GlideModule extends RegistersComponents, AppliesOptions {
}
