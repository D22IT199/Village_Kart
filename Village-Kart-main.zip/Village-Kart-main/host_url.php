<?php
$host_url = "http://192.168.0.102/";
$projectName = "village_kart";

