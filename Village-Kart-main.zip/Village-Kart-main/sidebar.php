<!-- Sidebar -->


<style type="text/css">

    #ul-sidebar {
        background-color: #B68E65;
    }

</style>

<ul class="sidebar navbar-nav" id="ul-sidebar">
    <li class="nav-item">
        <a class="nav-link" href="index.php">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Manage Users</span>
        </a>
    </li>


    <li class="nav-item">
        <a class="nav-link" href="manage_cat.php">
            <i class="fa fa-product-hunt" aria-hidden="true"></i>
            <span>Manage Category</span>
        </a>
    </li>


    <li class="nav-item">
        <a class="nav-link" href="manage_product.php">
            <i class="fa fa-bank" aria-hidden="true"></i>
            <span>Manage Product</span>
        </a>
    </li>

    <li class="nav-item">
        <a class="nav-link" href="order_details.php">
            <i class="fa fa-bank" aria-hidden="true"></i>
            <span>Order Details</span>

        </a>
    </li>


</ul>