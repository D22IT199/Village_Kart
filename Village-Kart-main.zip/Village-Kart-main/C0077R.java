package com.bumptech.glide.gifdecoder;

/* renamed from: com.bumptech.glide.gifdecoder.R */
public final class C0077R {
    private C0077R() {
    }
}
