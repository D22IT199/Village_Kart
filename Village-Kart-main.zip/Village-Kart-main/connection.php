<!DOCTYPE html>
<?php
 
$host="localhost";
$user="root";
$password="";
$db="village_kart";
 

$conn=mysqli_connect($host, $user, $password, $db);

if($conn){
    
    
    
}


?>