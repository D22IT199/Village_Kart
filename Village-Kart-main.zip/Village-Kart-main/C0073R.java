package com.android.volley;

/* renamed from: com.android.volley.R */
public final class C0073R {
    private C0073R() {
    }
}
